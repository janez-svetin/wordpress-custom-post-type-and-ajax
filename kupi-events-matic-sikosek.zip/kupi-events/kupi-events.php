<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              http://wordpress.org/
 * @since             1.0.0
 * @package           Kupi_Events
 *
 * @wordpress-plugin
 * Plugin Name:       Kupi.si Events
 * Plugin URI:        http://wordpress.org/
 * Description:       This is a short description of what the plugin does. It's displayed in the WordPress admin area.
 * Version:           1.0.0
 * Author:            Matic Sikosek
 * Author URI:        http://wordpress.org/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       kupi-events
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-kupi-events-activator.php
 */
function activate_kupi_events() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-kupi-events-activator.php';
	Kupi_Events_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-kupi-events-deactivator.php
 */
function deactivate_kupi_events() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-kupi-events-deactivator.php';
	Kupi_Events_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_kupi_events' );
register_deactivation_hook( __FILE__, 'deactivate_kupi_events' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-kupi-events.php';

// register CPT
require plugin_dir_path( __FILE__ ) . 'includes/class-kupi-events_register_cpt.php';

// register template for displaying CPT and single CPT
add_filter( 'template_include', 'include_template_function', 1 );

function include_template_function( $template_path ) {
    if ( get_post_type() == 'event' ) {
        if ( is_single() ) {
            // checks if the file exists in the theme first,
            // otherwise serve the file from the plugin
            if ( $theme_file = locate_template( array ( 'single-event.php' ) ) ) {
                $template_path = $theme_file;
            } else {
                $template_path = plugin_dir_path( __FILE__ ) . '/single-event.php';
            }
        }
        if ( is_archive() ) {
            // checks if the file exists in the theme first,
            // otherwise serve the file from the plugin
            if ( $theme_file = locate_template( array ( 'display-events.php' ) ) ) {
                $template_path = $theme_file;
            } else {
                $template_path = plugin_dir_path( __FILE__ ) . '/display-events.php';
            }
        }
    }
    return $template_path;
}

add_action( 'wp_ajax_nopriv_ajax_pagination', 'my_ajax_pagination' );
add_action( 'wp_ajax_ajax_pagination', 'my_ajax_pagination' );
add_action( 'wp_ajax_ajax_pagination_new', 'my_ajax_pagination_new' );
function my_ajax_pagination_new() {

// WP_Query arguments
$args = array (
	'post_type'              => array( 'event' ),
	'nopaging'               => true,
	'posts_per_page'         => '5',
	'meta_query'             => array(
		array(
			'key'       => 'my_event_type_select',
			'value'     => '$cpt_name',
			'compare'   => '=',
			'type'      => 'CHAR',
		),
	),
);

// The Query
$query = new WP_Query( $args );

}
function my_ajax_pagination() {
//$query_vars =array();
$query_vars = json_decode( stripslashes( $_POST['page'] ), true );
$query_vars = $_POST['page'];


$args = array( 'post_type' => 'event', 
'posts_per_page' => 5,
'paged' => $query_vars,
);
		
$posts = new WP_Query( $args );
//if ($etp != "") $GLOBALS['wp_query'] = $posts;
$GLOBALS['wp_query'] = $posts;
add_filter( 'editor_max_image_size', 'my_image_size_override' );
if( ! $posts->have_posts() ) {
echo "no more events to show!";
}
else {
while ( $posts->have_posts() ) {
$posts->the_post();
	global $post;
	$my_selected_event_type  = get_post_meta( $post->ID, 'my_event_type_select', true );
	$my_event_location  = get_post_meta( $post->ID, 'my_event_location', true );
	
	$my_event_p_free_parking  = get_post_meta( $post->ID, 'my_event_p_free_parking', true );
	$my_event_p_free_lunch  = get_post_meta( $post->ID, 'my_event_p_free_lunch', true );
	$my_event_p_early_bird  = get_post_meta( $post->ID, 'my_event_p_early_bird', true );
	$my_event_p_free_drinks  = get_post_meta( $post->ID, 'my_event_p_free_drinks', true );
	$my_event_p_free_tshirt  = get_post_meta( $post->ID, 'my_event_p_free_tshirt', true );
	$my_event_p_e_ticket  = get_post_meta( $post->ID, 'my_event_p_e_ticket', true );
	
	// Retrieve current date for cookie
	$eventstartdate = get_post_meta( $post->ID, 'event_start_date', true  );
	$eventenddate = get_post_meta( $post->ID, 'event_end_date', true  );
    // if there is previously saved value then retrieve it, else set it to the current time
    $eventstartdate = ! empty( $eventstartdate ) ? $eventstartdate : date("m/d/y");
 
    //we assume that if the end date is not present, event ends on the same day
    $eventenddate = ! empty( $eventenddate ) ? $eventenddate : $eventstartdate;
	
	$selected_event_type = isset( $my_selected_event_type ) ? $my_selected_event_type : '';
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php
		// Post thumbnail.
		twentyfifteen_post_thumbnail('Events-thumb-m');
	?>

	<header class="entry-header">
		<?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
	</header><!-- .entry-header -->

	<div class="entry-content">
	<div class="cpt-event-single">
	<div style="width:45%; float:left;display:block;overflow:auto;">
	<p>Event Type: <?php echo ucfirst($my_selected_event_type); ?></p>
	<p>Event Location: <?php echo $my_event_location; ?></p>
	<p>Event Start Date: <?php echo $eventstartdate; ?></p>
	<?php if (( $my_selected_event_type== "conference" ) || ( $my_selected_event_type == "festival" )) { ?>
	<p>Event End Date: <?php echo $eventenddate; ?></p>
	<?php } ?>
	</div>
	<div style="width:45%; float:right;display:block;overflow:auto;">
	<?php if ( $my_event_p_free_parking == "on" ) echo '<p><span class="icn-properties icn-parking"></span> Free parking</p>'; ?>
	<?php if ( $my_event_p_free_lunch == "on" ) echo '<p><span class="icn-properties icn-lunch"></span> Free Lunch</p>'; ?>
	<?php if ( $my_event_p_early_bird == "on" ) { ?>
	<p><span class="icn-properties icn-ticket"></span> Early bird tickets</p>
	<?php } ?>
	<?php if ( $my_event_p_free_drinks == "on" ) { ?>
	<p><span class="icn-properties icn-drink"></span> Free drinks</p>
	<?php } ?>
	<?php if ( $my_event_p_free_tshirt == "on" ) echo '<p><span class="icn-properties icn-shirt"></span> Free T-shirt</p>'; ?>
	<?php if ( $my_event_p_e_ticket == "on" ) { ?>
	<p><span class="icn-properties icn-ticket"></span> E-ticket Purchase</p>
	<?php } ?>

	</div>
	<div style="clear:both;"></div>
	<?php //the_content(); ?>
		<?php //the_content(); ?>
		<?php
			wp_link_pages( array(
				'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'twentyfifteen' ) . '</span>',
				'after'       => '</div>',
				'link_before' => '<span>',
				'link_after'  => '</span>',
				'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'twentyfifteen' ) . ' </span>%',
				'separator'   => '<span class="screen-reader-text">, </span>',
			) );
		?>
	</div><!-- .cpt-event-single -->
	</div><!-- .entry-content -->

	<?php edit_post_link( __( 'Edit', 'twentyfifteen' ), '<footer class="entry-footer"><span class="edit-link">', '</span></footer><!-- .entry-footer -->' ); ?>

</article><!-- #post-## -->
<?php 	
}
}
remove_filter( 'editor_max_image_size', 'my_image_size_override' );
the_posts_pagination( array(
'prev_text' => __( 'Previous page', 'twentyfifteen' ),
'next_text' => __( 'Next page', 'twentyfifteen' ),
'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'twentyfifteen' ) . ' </span>',
) );
die();
}
function my_image_size_override() {
return array( 825, 510 );
}
/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_kupi_events() {

	$plugin = new Kupi_Events();
	$plugin->run();

}
run_kupi_events();
