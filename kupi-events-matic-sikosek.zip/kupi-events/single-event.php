<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

		<?php
		// Start the loop.
		while ( have_posts() ) : the_post();

			/*
			 * Include the post format-specific template for the content. If you want to
			 * use this in a child theme, then include a file called called content-___.php
			 * (where ___ is the post format) and that will be used instead.
			 */
				global $post;
	$my_selected_event_type  = get_post_meta( $post->ID, 'my_event_type_select', true );
	$my_event_location  = get_post_meta( $post->ID, 'my_event_location', true );
	
	$my_event_p_free_parking  = get_post_meta( $post->ID, 'my_event_p_free_parking', true );
	$my_event_p_free_lunch  = get_post_meta( $post->ID, 'my_event_p_free_lunch', true );
	$my_event_p_early_bird  = get_post_meta( $post->ID, 'my_event_p_early_bird', true );
	$my_event_p_free_drinks  = get_post_meta( $post->ID, 'my_event_p_free_drinks', true );
	$my_event_p_free_tshirt  = get_post_meta( $post->ID, 'my_event_p_free_tshirt', true );
	$my_event_p_e_ticket  = get_post_meta( $post->ID, 'my_event_p_e_ticket', true );
	
	// Retrieve current date for cookie
	$eventstartdate = get_post_meta( $post->ID, 'event_start_date', true  );
	$eventenddate = get_post_meta( $post->ID, 'event_end_date', true  );
    // if there is previously saved value then retrieve it, else set it to the current time
    $eventstartdate = ! empty( $eventstartdate ) ? $eventstartdate : date("m/d/y");
 
    //we assume that if the end date is not present, event ends on the same day
    $eventenddate = ! empty( $eventenddate ) ? $eventenddate : $eventstartdate;
	
	$selected_event_type = isset( $my_selected_event_type ) ? $my_selected_event_type : '';
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php
		// Post thumbnail.
		twentyfifteen_post_thumbnail('Events-thumb-m');
	?>

	<header class="entry-header">
		<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
	</header><!-- .entry-header -->

	<div class="entry-content">
	<div class="cpt-event-single">
	<div style="width:45%; float:left;display:block;overflow:auto;">
	<p>Event Type: <?php echo ucfirst($my_selected_event_type); ?></p>
	<p>Event Location: <?php echo $my_event_location; ?></p>
	<p>Event Start Date: <?php echo $eventstartdate; ?></p>
	<?php if (( $my_selected_event_type== "conference" ) || ( $my_selected_event_type == "festival" )) { ?>
	<p>Event End Date: <?php echo $eventenddate; ?></p>
	<?php } ?>
	</div>
	<div style="width:45%; float:right;display:block;overflow:auto;">
	<?php if ( $my_event_p_free_parking == "on" ) echo '<p><span class="icn-properties icn-parking"></span> Free parking</p>'; ?>
	<?php if ( $my_event_p_free_lunch == "on" ) echo '<p><span class="icn-properties icn-lunch"></span> Free Lunch</p>'; ?>
	<?php if ( $my_event_p_early_bird == "on" ) { ?>
	<p><span class="icn-properties icn-ticket"></span> Early bird tickets</p>
	<?php } ?>
	<?php if ( $my_event_p_free_drinks == "on" ) { ?>
	<p><span class="icn-properties icn-drink"></span> Free drinks</p>
	<?php } ?>
	<?php if ( $my_event_p_free_tshirt == "on" ) echo '<p><span class="icn-properties icn-shirt"></span> Free T-shirt</p>'; ?>
	<?php if ( $my_event_p_e_ticket == "on" ) { ?>
	<p><span class="icn-properties icn-ticket"></span> E-ticket Purchase</p>
	<?php } ?>

	</div>
	<div style="clear:both;"></div>
	<?php the_content(); ?>
		<?php //the_content(); ?>
		<?php
			wp_link_pages( array(
				'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'twentyfifteen' ) . '</span>',
				'after'       => '</div>',
				'link_before' => '<span>',
				'link_after'  => '</span>',
				'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'twentyfifteen' ) . ' </span>%',
				'separator'   => '<span class="screen-reader-text">, </span>',
			) );
		?>
	</div><!-- .cpt-event-single -->
	</div><!-- .entry-content -->

	<?php edit_post_link( __( 'Edit', 'twentyfifteen' ), '<footer class="entry-footer"><span class="edit-link">', '</span></footer><!-- .entry-footer -->' ); ?>

</article><!-- #post-## -->
<?php 
			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

		// End the loop.
		endwhile;
		?>

		</main><!-- .site-main -->
	</div><!-- .content-area -->

<?php get_footer(); ?>
