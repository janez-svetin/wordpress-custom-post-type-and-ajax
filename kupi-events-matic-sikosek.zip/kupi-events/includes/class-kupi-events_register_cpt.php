<?php 
new EventsPostType;		// Initial call

class EventsPostType {
	
  var $single = "Event"; 	// this represents the singular name of the post type
  var $plural = "Events"; 	// this represents the plural name of the post type
  var $type 	= "Event"; 	// this is the actual type

	# credit: http://w3prodigy.com/behind-wordpress/php-classes-wordpress-plugin/
	function EventsPostType()
	{
		$this->__construct();
	}

	function __construct()
	{
		# Place your add_actions and add_filters here
		add_action( 'init', array( &$this, 'init' ) );
		add_action('init', array(&$this, 'add_post_type'));
		
		# Add image support 
		add_theme_support('post-thumbnails', array( $this->type ) );
		add_image_size(strtolower($this->plural).'-thumb-s', 220, 160, true);
		add_image_size(strtolower($this->plural).'-thumb-m', 300, 180, true);

		# Add Post Type to Search 
		add_filter('pre_get_posts', array( &$this, 'query_post_type') );

		# Add Custom Taxonomy for Event Type
		//add_action( 'init', array( &$this, 'add_taxonomy_event_type') );
		
		# Add Custom Taxonomy for Event Properties
		//add_action( 'init', array( &$this, 'add_taxonomy_event_properties') );

		# Add meta box
		add_action('add_meta_boxes', array( &$this, 'add_custom_metaboxes') );

		# Save entered data
		add_action('save_post', array( &$this, 'save_postdata') );

	} 
	
	# @credit: http://www.wpinsideout.com/advanced-custom-post-types-php-class-integration
  function init($options = null){
  	if($options) {
	    foreach($options as $key => $value){
	      $this->$key = $value;
	    }
    }
  }

	function add_post_type(){
    $labels = array(
		'name'                  => _x( 'Events', 'Post Type General Name', 'kupi_event' ),
		'singular_name'         => _x( 'Event', 'Post Type Singular Name', 'kupi_event' ),
		'menu_name'             => __( 'Events', 'kupi_event' ),
		'name_admin_bar'        => __( 'Events', 'kupi_event' ),
		'archives'              => __( 'Event Archives', 'kupi_event' ),
		'parent_Event_colon'     => __( 'Parent Event:', 'kupi_event' ),
		'all_Events'             => __( 'All Events', 'kupi_event' ),
		'add_new_Event'          => __( 'Add New Event', 'kupi_event' ),
		'add_new'               => __( 'Add Event', 'kupi_event' ),
		'new_Event'              => __( 'New Event', 'kupi_event' ),
		'edit_Event'             => __( 'Edit Event', 'kupi_event' ),
		'update_Event'           => __( 'Update Event', 'kupi_event' ),
		'view_Event'             => __( 'View Event', 'kupi_event' ),
		'search_Events'          => __( 'Search Event', 'kupi_event' ),
		'not_found'             => __( 'Not found', 'kupi_event' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'kupi_event' ),
		'featured_image'        => __( 'Featured Image', 'kupi_event' ),
		'set_featured_image'    => __( 'Set featured image', 'kupi_event' ),
		'remove_featured_image' => __( 'Remove featured image', 'kupi_event' ),
		'use_featured_image'    => __( 'Use as featured image', 'kupi_event' ),
		'insert_into_Event'      => __( 'Insert into Event', 'kupi_event' ),
		'uploaded_to_this_Event' => __( 'Uploaded to this Event', 'kupi_event' ),
		'Events_list'            => __( 'Events list', 'kupi_event' ),
		'Events_list_navigation' => __( 'Events list navigation', 'kupi_event' ),
		'filter_Events_list'     => __( 'Filter Events list', 'kupi_event' ),
    );
    $options = array(
		'label'                 => __( 'Event', 'kupi_event' ),
		'description'           => __( 'Events for Kupi', 'kupi_event' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'revisions', 'custom-fields' ),
		//'taxonomies'            => array( 'post_tag' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
      
    );
    register_post_type($this->type, $options);
  }

	
	function query_post_type($query) {
	  if(is_category() || is_tag()) {
	    $post_type = get_query_var('post_type');
		if($post_type) {
		  $post_type = $post_type;
		} else {
		  $post_type = array($this->type); // replace cpt to your custom post type
	  }
	  $query->set('post_type',$post_type);
		return $query;
	  }
	}
/*
function add_taxonomy_event_type() {
	// Add new taxonomy, NOT hierarchical (like tags)
	$labels = array(
		'name'                       => _x( 'Event Types', 'kupi_event' ),
		'singular_name'              => _x( 'Location', 'taxonomy singular name' ),
		'search_items'               => __( 'Search Event Types' ),
		'popular_items'              => __( 'Popular Event Types' ),
		'all_items'                  => __( 'All Event Types' ),
		'parent_item'                => null,
		'parent_item_colon'          => null,
		'edit_item'                  => __( 'Edit Event Type' ),
		'update_item'                => __( 'Update Event Type' ),
		'add_new_item'               => __( 'Add New Event Type' ),
		'new_item_name'              => __( 'New Event Type Name' ),
		'separate_items_with_commas' => __( 'Separate Event Types with commas' ),
		'add_or_remove_items'        => __( 'Add or remove Event Types' ),
		'choose_from_most_used'      => __( 'Choose from the most used Event Types' ),
		'not_found'                  => __( 'No Event Types found.' ),
		'menu_name'                  => __( 'Event Type' ),
	);

	$args = array(
		'hierarchical'          => false,
		'labels'                => $labels,
		'show_ui'               => true,
		'show_admin_column'     => true,
		'update_count_callback' => '_update_post_term_count',
		'query_var'             => true,
		'rewrite'               => false,
		'public' => false,
	);
	/*
	/* this is a taxonomy for adding Event Properties
	register_taxonomy( 'event_type', 'event', $args );

	}
	function add_taxonomy_event_properties() {
	// Add new taxonomy, NOT hierarchical (like tags)
	$labels = array(
		'name'                       => _x( 'Event Types', 'kupi_event' ),
		'singular_name'              => _x( 'Location', 'taxonomy singular name' ),
		'search_items'               => __( 'Search Event Types' ),
		'popular_items'              => __( 'Popular Event Types' ),
		'all_items'                  => __( 'All Event Types' ),
		'parent_item'                => null,
		'parent_item_colon'          => null,
		'edit_item'                  => __( 'Edit Event Type' ),
		'update_item'                => __( 'Update Event Properties' ),
		'add_new_item'               => __( 'Add New Event Properties' ),
		'new_item_name'              => __( 'New  Event Properties Name' ),
		'separate_items_with_commas' => __( 'Separate  Event Properties with commas' ),
		'add_or_remove_items'        => __( 'Add or remove Event Propertiess' ),
		'choose_from_most_used'      => __( 'Choose from the most used  Event Propertiess' ),
		'not_found'                  => __( 'No  Event Propertiess found.' ),
		'menu_name'                  => __( ' Event Properties' ),
	);

	$args = array(
		'hierarchical'          => false,
		'labels'                => $labels,
		'show_ui'               => true,
		'show_admin_column'     => true,
		'update_count_callback' => '_update_post_term_count',
		'query_var'             => true,
		'rewrite'               => false,
		'public' => false,
	);

	register_taxonomy( 'event_properties', 'event', $args );
	}
	*/
	function add_custom_metaboxes() {
    add_meta_box( 'metabox', 'Event Type', array( &$this, 'metabox_event_type'), $this->type, 'normal', 'high' );
	}

	function metabox_event_type() {
    // $post is already set, and contains an object: the WordPress post
    global $post;
    $values = get_post_custom( $post->ID );
	
	// check which Event type we have
	$my_selected_event_type  = get_post_meta( $post->ID, 'my_event_type_select', true );
	$my_event_location  = get_post_meta( $post->ID, 'my_event_location', true );
	
	$my_event_p_free_parking  = get_post_meta( $post->ID, 'my_event_p_free_parking', true );
	$my_event_p_free_lunch  = get_post_meta( $post->ID, 'my_event_p_free_lunch', true );
	$my_event_p_early_bird  = get_post_meta( $post->ID, 'my_event_p_early_bird', true );
	$my_event_p_free_drinks  = get_post_meta( $post->ID, 'my_event_p_free_drinks', true );
	$my_event_p_free_tshirt  = get_post_meta( $post->ID, 'my_event_p_free_tshirt', true );
	$my_event_p_e_ticket  = get_post_meta( $post->ID, 'my_event_p_e_ticket', true );
	
	// Retrieve current date for cookie
	$eventstartdate = get_post_meta( $post->ID, 'event_start_date', true  );
	$eventenddate = get_post_meta( $post->ID, 'event_end_date', true  );
    // if there is previously saved value then retrieve it, else set it to the current time
    $eventstartdate = ! empty( $eventstartdate ) ? $eventstartdate : date("m/d/y");
 
    //we assume that if the end date is not present, event ends on the same day
    $eventenddate = ! empty( $eventenddate ) ? $eventenddate : $eventstartdate;
	
	$selected_event_type = isset( $my_selected_event_type ) ? $my_selected_event_type : '';
	
    // We'll use this nonce field later on when saving.
    wp_nonce_field( 'my_meta_box_nonce', 'meta_box_nonce' );
	
	/*
	/* Arguments for displaying taxonomiy "Event Properties" with wp_dropdown_categories
	$args = array(
		'show_option_all'    => '',
		'show_option_none'   => '',
		'option_none_value'  => '',
		'orderby'            => 'SLUG', 
		'order'              => 'ASC',
		'show_count'         => 0,
		'hide_empty'         => 0, 
		'child_of'           => 0,
		'exclude'            => '',
		'echo'               => 1,
		'selected'           => $selected_event_type,
		'hierarchical'       => 0, 
		'name'               => 'my_event_type_select',
		'id'                 => 'my_event_type_select',
		'class'              => 'postform',
		'depth'              => 0,
		'tab_index'          => 0,
		'taxonomy'           => 'event_type',
		'hide_if_empty'      => false,
		'value_field'	     => 'slug',	
	);  
	*/
  //wp_dropdown_categories( $args );

    ?>
    <p>
        <label for="my_event_location">Event location</label>
        <input type="text" name="my_event_location" id="my_event_location" value="<?php echo $my_event_location; ?>" />
    </p>
     
    <p>
        <label for="my_event_type_select">Select Type of the Event</label>

		<?php //wp_dropdown_categories( $args ); ?>
		<select class="postform" id="my_event_type_select" name="my_event_type_select" onChange="toggle();">
			<option <?php echo ($my_selected_event_type == 'concert') ? ' selected="selected"' : '' ?>value="concert">Concert</option>
			<option <?php echo ($my_selected_event_type == 'conference') ? ' selected="selected"' : '' ?>value="conference">Conference</option>
			<option <?php echo ($my_selected_event_type == 'festival') ? ' selected="selected"' : '' ?> value="festival">Festival</option>
			<option <?php echo ($my_selected_event_type == 'theatre') ? ' selected="selected"' : '' ?>value="theatre">Theatre</option>
		</select>
    </p>
	<p>
	
	<div id="StartDateDiv">
	Event Start Date<input type="text" name="eventstartdate" id="eventstartdate" value="<?php echo $eventstartdate; ?>" />
	</div>
	<div id="EndDateDiv">
	Event End Date<input type="text" name="eventenddate" id="eventenddate" value="<?php echo $eventenddate; ?>" />
	</div>
	<script>
    var vall = document.getElementById("my_event_type_select").options[document.getElementById("my_event_type_select").selectedIndex].value;
    if ( vall == "festival" || vall == "conference" ) {
       document.getElementById("EndDateDiv").style.display = "block";
    } else {
       document.getElementById("EndDateDiv").style.display = "none";
    }
	</script>
	</p>
    <p>
		<label>Event Properties</label>
	</p>
	<p>
        <input type="checkbox" id="my_event_p_free_parking" name="my_event_p_free_parking" <?php checked( $my_event_p_free_parking, 'on' ); ?> />
        <label>Free parking</label><br />
        <input type="checkbox" id="my_event_p_free_lunch" name="my_event_p_free_lunch" <?php checked( $my_event_p_free_lunch, 'on' ); ?> />
        <label>Free lunch</label><br />
        <input type="checkbox" id="my_event_p_early_bird" name="my_event_p_early_bird" <?php checked( $my_event_p_early_bird, 'on' ); ?> />
        <label>Early bird option</label><br />
        <input type="checkbox" id="my_event_p_free_drinks" name="my_event_p_free_drinks" <?php checked( $my_event_p_free_drinks, 'on' ); ?> />
        <label>Free drinks</label><br />
        <input type="checkbox" id="my_event_p_free_tshirt" name="my_event_p_free_tshirt" <?php checked( $my_event_p_free_tshirt, 'on' ); ?> />
        <label>Free t-shirt</label><br />
        <input type="checkbox" id="my_event_p_e_ticket" name="my_event_p_e_ticket" <?php checked( $my_event_p_e_ticket, 'on' ); ?> />
        <label>E ticket available</label><br />

    </p>

    <?php  
	}
// Add meta box goes into our admin_init function

 

	function save_postdata($post_id ){
	global $post;   
    // Bail if we're doing an auto save
    if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
     
    // if our nonce isn't there, or we can't verify it, bail
    if( !isset( $_POST['meta_box_nonce'] ) || !wp_verify_nonce( $_POST['meta_box_nonce'], 'my_meta_box_nonce' ) ) return;
     
    // if our current user can't edit this post, bail
    if( !current_user_can( 'edit_post' ) ) return;
     

    // Make sure your data is set before trying to save it
    if( isset( $_POST['my_event_location'] ) )
        update_post_meta( $post_id, 'my_event_location', $_POST['my_event_location'] );
         
    if( isset( $_POST['my_event_type_select'] ) )
        update_post_meta( $post_id, 'my_event_type_select', $_POST['my_event_type_select'] );
         
    $chk = isset( $_POST['my_event_p_free_parking'] ) && $_POST['my_event_p_free_parking'] ? 'on' : 'off';
    update_post_meta( $post_id, 'my_event_p_free_parking', $chk );
	$chk = "";
    $chk = isset( $_POST['my_event_p_free_lunch'] ) && $_POST['my_event_p_free_lunch'] ? 'on' : 'off';
    update_post_meta( $post_id, 'my_event_p_free_lunch', $chk );
	$chk = "";
    $chk = isset( $_POST['my_event_p_early_bird'] ) && $_POST['my_event_p_early_bird'] ? 'on' : 'off';
    update_post_meta( $post_id, 'my_event_p_early_bird', $chk );
	$chk = "";
    $chk = isset( $_POST['my_event_p_free_drinks'] ) && $_POST['my_event_p_free_drinks'] ? 'on' : 'off';
    update_post_meta( $post_id, 'my_event_p_free_drinks', $chk );
	$chk = "";
    $chk = isset( $_POST['my_event_p_free_tshirt'] ) && $_POST['my_event_p_free_tshirt'] ? 'on' : 'off';
    update_post_meta( $post_id, 'my_event_p_free_tshirt', $chk );
	$chk = "";
    $chk = isset( $_POST['my_event_p_e_ticket'] ) && $_POST['my_event_p_e_ticket'] ? 'on' : 'off';
    update_post_meta( $post_id, 'my_event_p_e_ticket', $chk );
	$chk = "";
    if( isset( $_POST['eventstartdate'] ) )
        update_post_meta( $post_id, 'event_start_date', $_POST['eventstartdate'] );
       
    if( isset( $_POST['eventenddate'] ) )
        update_post_meta( $post_id, 'event_end_date', $_POST['eventenddate'] );

	}


}
