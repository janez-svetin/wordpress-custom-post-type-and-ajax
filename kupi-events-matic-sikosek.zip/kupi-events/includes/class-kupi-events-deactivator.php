<?php

/**
 * Fired during plugin deactivation
 *
 * @link       http://wordpress.org/
 * @since      1.0.0
 *
 * @package    Kupi_Events
 * @subpackage Kupi_Events/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Kupi_Events
 * @subpackage Kupi_Events/includes
 * @author     Matic Sikosek <matic.sikosek@gmail.com>
 */
class Kupi_Events_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
