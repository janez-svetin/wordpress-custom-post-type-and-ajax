
jQuery	(document).ready(function(){
    jQuery("#eventstartdate").datepicker({
        numberOfMonths: 2,
		minDate: 0, 
        onSelect: function(selected) {
          jQuery("#eventenddate").datepicker("option","minDate", selected)
        }
    });
    jQuery("#eventenddate").datepicker({ 
        numberOfMonths: 2,
        onSelect: function(selected) {
           jQuery("#eventstartdate").datepicker("option","maxDate", selected)
        }
    });  

}); 
  function toggle() {
    var val = document.getElementById("my_event_type_select").options[document.getElementById("my_event_type_select").selectedIndex].value;
    if ( val == "festival" || val == "conference" ) {
       document.getElementById("EndDateDiv").style.display = "block";
    } else {
       document.getElementById("EndDateDiv").style.display = "none";
    }
  }

